import numpy as np
from samples import loadDataFile, loadLabelsFile
from sklearn.naive_bayes import GaussianNB, MultinomialNB
from sklearn.neighbors import KNeighborsClassifier
import numpy as np

def train(xTraining, yTraining, xTest, yTest):
    gnb = GaussianNB()
    yPredictionGNB = gnb.fit(xTraining, yTraining).predict(xTest)

    mnb = MultinomialNB()
    yPredictionMNB = mnb.fit(xTraining, yTraining).predict(xTest)

    yPredictionsKNN = {"Manhattan": {"uniform": [], "distance": []}, "Euclidean": {"uniform": [], "distance": []}}
    for k in range(1, 21): 
        knnMU = KNeighborsClassifier(k, p = 1, weights = "uniform")
        knnEU = KNeighborsClassifier(k, p = 2, weights = "uniform")
        knnMD = KNeighborsClassifier(k, p = 1, weights = "distance")
        knnED = KNeighborsClassifier(k, p = 2, weights = "distance")
        yPredictionsKNN["Manhattan"]["uniform"].append(knnMU.fit(xTraining, yTraining).predict(xTest))
        yPredictionsKNN["Euclidean"]["uniform"].append(knnEU.fit(xTraining, yTraining).predict(xTest))
        yPredictionsKNN["Manhattan"]["distance"].append(knnMD.fit(xTraining, yTraining).predict(xTest))
        yPredictionsKNN["Euclidean"]["distance"].append(knnED.fit(xTraining, yTraining).predict(xTest))
        
    return yPredictionGNB, yPredictionMNB, yPredictionsKNN

if __name__ == "__main__":
    nTrainingDigits = 5000
    nTestDigits = 1000
        
    nTrainingFaces = 451
    nTestFaces = 150

    xTrainingDigits = [np.concatenate(Datum.uninvertedPixels) for Datum in loadDataFile("digitdata/trainingimages", nTrainingDigits,28,28)]
    yTrainingDigits = loadLabelsFile("digitdata/traininglabels", nTrainingDigits)

    xTestDigits = [np.concatenate(Datum.uninvertedPixels) for Datum in loadDataFile("digitdata/testimages", nTestDigits,28,28)]
    yTestDigits = loadLabelsFile("digitdata/testlabels", nTestDigits)

    xTrainingFaces = [np.concatenate(Datum.uninvertedPixels) for Datum in loadDataFile("facedata/facedatatrain", nTrainingFaces,60,70)]
    yTrainingFaces = loadLabelsFile("facedata/facedatatrainlabels", nTrainingFaces)

    xTestFaces = [np.concatenate(Datum.uninvertedPixels) for Datum in loadDataFile("facedata/facedatatest", nTestFaces, 60, 70)]
    yTestFaces = loadLabelsFile("facedata/facedatatestlabels", nTestFaces)

    yPredictionGNBDigits, yPredictionMNBDigits, yPredictionsKNNDigits = train(xTrainingDigits, yTrainingDigits, xTestDigits, yTestDigits)
    yPredictionGNBFaces, yPredictionMNBFaces, yPredictionsKNNFaces = train(xTrainingFaces, yTrainingFaces, xTestFaces, yTestFaces)

    print("----------------------------Digits----------------------------")
    print(f"Number of mislabeled points by Gaussian Naive Bayes: {(yTestDigits != yPredictionGNBDigits).sum()}")
    print(f"Accuracy of Gaussian Naive Bayes: {round((1 - (yTestDigits != yPredictionGNBDigits).sum() / nTestDigits) * 100, 2)}%\n")
    print(f"Number of mislabeled points by Multinomial Naive Bayes: {(yTestDigits != yPredictionMNBDigits).sum()}")
    print(f"Accuracy of Multinomial Naive Bayes: {round((1 - (yTestDigits != yPredictionMNBDigits).sum() / nTestDigits) * 100, 2)}%")
    print("\n\n")
    print("-----------------------------Faces-----------------------------")
    print(f"Number of mislabeled points by Gaussian Naive Bayes: {(yTestFaces != yPredictionGNBFaces).sum()}")
    print(f"Accuracy of Gaussian Naive Bayes: {round((1 - (yTestFaces != yPredictionGNBFaces).sum() / nTestFaces) * 100, 2)}%\n")
    print(f"Number of mislabeled points by Multinomial Naive Bayes: {(yTestFaces != yPredictionMNBFaces).sum()}")
    print(f"Accuracy of Multinomial Naive Bayes: {round((1 - (yTestFaces != yPredictionMNBFaces).sum() / nTestFaces) * 100, 2)}%")