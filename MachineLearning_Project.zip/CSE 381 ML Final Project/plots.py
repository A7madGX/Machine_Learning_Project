import matplotlib.pyplot as plt
import numpy as np
from training import train
from samples import loadDataFile, loadLabelsFile

nTrainingDigits = 5000
nTestDigits = 1000

nTrainingFaces = 451
nTestFaces = 150

xTrainingDigits = [np.concatenate(Datum.uninvertedPixels) for Datum in loadDataFile("digitdata/trainingimages", nTrainingDigits,28,28)]
yTrainingDigits = loadLabelsFile("digitdata/traininglabels", nTrainingDigits)

xTestDigits = [np.concatenate(Datum.uninvertedPixels) for Datum in loadDataFile("digitdata/testimages", nTestDigits,28,28)]
yTestDigits = loadLabelsFile("digitdata/testlabels", nTestDigits)

xTrainingFaces = [np.concatenate(Datum.uninvertedPixels) for Datum in loadDataFile("facedata/facedatatrain", nTrainingFaces,60,70)]
yTrainingFaces = loadLabelsFile("facedata/facedatatrainlabels", nTrainingFaces)

xTestFaces = [np.concatenate(Datum.uninvertedPixels) for Datum in loadDataFile("facedata/facedatatest", nTestFaces, 60, 70)]
yTestFaces = loadLabelsFile("facedata/facedatatestlabels", nTestFaces)

yPredictionGNBDigits, yPredictionMNBDigits, yPredictionsKNNDigits = train(xTrainingDigits, yTrainingDigits, xTestDigits, yTestDigits)
yPredictionGNBFaces, yPredictionMNBFaces, yPredictionsKNNFaces = train(xTrainingFaces, yTrainingFaces, xTestFaces, yTestFaces)

"""

    The Naive Bayes Line Chart: 
    
"""
classifiers = ["Gaussian\n(Digits)", "Multinomial\n(Digits)", "Gaussian\n(Faces)", "Multinomial\n(Faces)"]
accuracy = [
    round((1 - (yTestDigits != yPredictionGNBDigits).sum() / nTestDigits) * 100, 2),
    round((1 - (yTestDigits != yPredictionMNBDigits).sum() / nTestDigits) * 100, 2),
    round((1 - (yTestFaces != yPredictionGNBFaces).sum() / nTestFaces) * 100, 2),
    round((1 - (yTestFaces != yPredictionMNBFaces).sum() / nTestFaces) * 100, 2)
]
plt.bar(classifiers, accuracy, color = ["#4a648c", "#4a648c", "#80629c", "#80629c"])
plt.ylabel("Accuracy (%)")
plt.show()

"""

    The KNN Line Chart:

"""

def plotKNN(yTest, yPredictionsKNN, nTest): 
    kAx = range(1, 21)
    accuracyManhattanU = [round((1 - (yTest != yPredictionKNN).sum() / nTest) * 100, 2) for yPredictionKNN in yPredictionsKNN["Manhattan"]["uniform"]]
    accuracyEuclideanU = [round((1 - (yTest != yPredictionKNN).sum() / nTest) * 100, 2) for yPredictionKNN in yPredictionsKNN["Euclidean"]["uniform"]]
    accuracyManhattanD = [round((1 - (yTest != yPredictionKNN).sum() / nTest) * 100, 2) for yPredictionKNN in yPredictionsKNN["Manhattan"]["distance"]]
    accuracyEuclideanD = [round((1 - (yTest != yPredictionKNN).sum() / nTest) * 100, 2) for yPredictionKNN in yPredictionsKNN["Euclidean"]["distance"]]

    fig, ax = plt.subplots()
    ax.plot(kAx, accuracyManhattanU, label = "Uniform Weights, Manhattan Distance")
    ax.plot(kAx, accuracyEuclideanU, label = "Uniform Weights, Euclidean Distance")
    ax.plot(kAx, accuracyManhattanD, label = "Distance Weights, Manhattan Distance")
    ax.plot(kAx, accuracyEuclideanD, label = "Distance Weights, Euclidean Distance")
    plt.xticks(np.arange(2, max(kAx)+1, 2))

    ax.set(xlabel='K (Number of Neighbors)', ylabel='Accuracy (%)')
    ax.grid()
    ax.legend()
    plt.show()
    
plotKNN(yTestDigits, yPredictionsKNNDigits, nTestDigits)
plotKNN(yTestFaces, yPredictionsKNNFaces, nTestFaces)

"""

    Overall Performance Bar Chart

"""

def plotDigitBars(yTestDigits, yPredictionGNBDigits, yPredictionMNBDigits, yPredictionsKNNDigits):
    fig, ax = plt.subplots()
    classifiers = ["Gaussian", "Multinomial", "KNN\n(Distance Weights)", "KNN\n(Uniform Weights)"]
    accuracy = [
        round((1 - (yTestDigits != yPredictionGNBDigits).sum() / nTestDigits) * 100, 2),
        round((1 - (yTestDigits != yPredictionMNBDigits).sum() / nTestDigits) * 100, 2),
        round((1 - (yTestDigits != yPredictionsKNNDigits["Euclidean"]["distance"][2]).sum() / nTestDigits) * 100, 2),
        round((1 - (yTestDigits != yPredictionsKNNDigits["Euclidean"]["uniform"][0]).sum() / nTestDigits) * 100, 2)
    ]
    ax.bar([1, 3, 5, 7], accuracy)
    plt.xticks([1, 3, 5, 7], classifiers)
    plt.title("Digit Classification")
    ax.set(ylabel = "Accuracy (%)")
    plt.show()

def plotFaceBars(yTestFaces, yPredictionGNBFaces, yPredictionMNBFaces, yPredictionsKNNFaces):
    fig, ax = plt.subplots()
    classifiers = ["Gaussian", "Multinomial", "KNN",]
    accuracy = [
        round((1 - (yTestFaces != yPredictionGNBFaces).sum() / nTestFaces) * 100, 2),
        round((1 - (yTestFaces != yPredictionMNBFaces).sum() / nTestFaces) * 100, 2),
        round((1 - (yTestFaces != yPredictionsKNNFaces["Euclidean"]["distance"][6]).sum() / nTestFaces) * 100, 2)
    ]
    ax.bar(classifiers, accuracy)
    plt.title("Face Detection")
    ax.set(ylabel = "Accuracy (%)")
    plt.show()
    
plotDigitBars(yTestDigits, yPredictionGNBDigits, yPredictionMNBDigits, yPredictionsKNNDigits)
plotFaceBars(yTestFaces, yPredictionGNBFaces, yPredictionMNBFaces, yPredictionsKNNFaces)